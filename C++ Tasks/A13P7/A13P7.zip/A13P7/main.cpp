//
//  main.cpp
//  A13P7
//
//  Created by Jose Ignacio Biehl on 30.11.19.
//  Copyright © 2019 Jose Biehl. All rights reserved.
//
/*Write a program which creates a vector of integers and adds the value 8, 20 times into the vector.
Include the library <vector> and then create a vector object which stores the 20 values from
above. Then write a try and catch block in which your code should try to access the 21th
element from the vector using the at() method. The exception you should catch should be of
type out_of_range. In the catch block use cerr to print to the standard error stream the type
of the exception by calling the redefined what() method inherited from the exception class.*/
#include <iostream>
#include <vector>
using namespace std;
int main(int argc, const char * argv[]) {
    vector<int> v(20, 8);
   /* for (int x : v){
        cout<<x<<" ";
    }*/
    try {
        cout<<v.at(20);
    } catch (std::out_of_range& a) {
        cerr<< a.what()<<endl;
        
    }
        
    return 0;
}
